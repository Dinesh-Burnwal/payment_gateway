export const DATA_PATTERN = '\\d{4}-\\d{2}-\\d{2}';
// The consent can be used max times per day
export const MAX_FREQUENCY_PER_DAY = 999;

export const DEFAULT_CURRENCY = 'EUR';
