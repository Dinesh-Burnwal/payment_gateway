export class StubUtilTests {
  public static AUTH_ID = 'AUTH_ID';
  public static REDIRECT_ID = 'REDIRECT_ID';
  public static SCA_METHOD_VALUE = '1234';
  public static DUMMY_INPUT = '12345';
}
