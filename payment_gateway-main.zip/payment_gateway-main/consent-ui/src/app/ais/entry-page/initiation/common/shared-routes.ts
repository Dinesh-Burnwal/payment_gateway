export class SharedRoutes {
  public static REVIEW = 'review-consent';
}
