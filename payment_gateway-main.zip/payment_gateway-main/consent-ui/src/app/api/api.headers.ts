export enum ApiHeaders {
  REDIRECT_CODE = 'Redirect-Code',
  X_XSRF_TOKEN = 'X-XSRF-TOKEN',
  LOCATION = 'Location',
  COOKIE_TTL = 'Cookie-TTL'
}
