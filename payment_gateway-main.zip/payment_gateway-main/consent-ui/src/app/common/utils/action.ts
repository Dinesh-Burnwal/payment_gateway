export enum Action {
  ACCOUNT = 'consent',
  PAYMENT = 'payment'
}
