// FIXME: This class should not exist and values here should come from API or elsewhere
export class StubUtil {
  public static FINTECH_NAME = 'Awesome FinTech';
  public static ASPSP_NAME = 'adorsys Sandbox';
  public static X_REQUEST_ID = 'a8b24683-242a-428b-8295-2f4805bb0a30';
}
