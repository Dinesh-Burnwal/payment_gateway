export class PisPayment {
  constructor(public extras?: { [key: string]: string }) {}
}
