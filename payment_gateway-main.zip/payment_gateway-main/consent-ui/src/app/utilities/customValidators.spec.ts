import { CustomValidators } from './customValidators';

describe('customValidators', () => {
  it('should create an instance', () => {
    expect(new CustomValidators()).toBeTruthy();
  });
});
