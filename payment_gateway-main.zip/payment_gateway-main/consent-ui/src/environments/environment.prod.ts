export const environment = {
  production: true,
  API_BASE_PATH: 'embedded-server'
};
