# End to End Perspective on PSU Data Protection 

## Standard Use Case 
![Standard Use Case](http://www.plantuml.com/plantuml/proxy?src=https://raw.githubusercontent.com/adorsys/open-banking-gateway/develop/docs/architecture/diagrams/useCases/psu-security.puml&fmt=svg&vvv=1&sanitize=true)  

## Session Fixation
![Standard Use Case](http://www.plantuml.com/plantuml/proxy?src=https://raw.githubusercontent.com/adorsys/open-banking-gateway/develop/docs/architecture/diagrams/useCases/psu-security attack.puml&fmt=svg&vvv=1&sanitize=true)  

