# Use Cases

- [Login with FinTech Application](1-loginWithFinTech.md)
- [Search Bank](2-searchBank.md)
- [Select Bank](3-selectBank.md)
- [List of Accounts](4a-aisListOfAccounts.md)
- [List of Transactions](4b-aisListOfTransactions.md)
- [Redirect to Consent Authorization API](5-redirectPsuToConsentAPI.md)
- [Authorize Consent Redirect Approach](5b-psuAuthRedirectConsent.md)
- [Authorize Consent Embedded Approach](5a-psuAuthEmbeddedConsent.md)
- [Consume Service](6-consume_api.md)






