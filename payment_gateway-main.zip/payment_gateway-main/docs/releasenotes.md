# Release Notes

## release 0.0.5
* Login Page creation for the Demo Frontend
* Change Test data with productive data for the TppBankSearchApi
* Update the general project's documentation
* Getting Started documentation
* Definition of the FinTechApi, BankingApi and ConsentAuthorisationApi
* Integration of Bank search API and FintechUI

## release 0.0.4

## release 0.0.3

* Write Sequence diagram uses cases based
* Validation of flowable BPMN engine (great job!)
* Backend Proof of Concept
* Implementation of TppBankSearchApi
* Create CI/CD code quality checks
* Write Contributions guidelines| 

