package de.adorsys.opba.fintech.api.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("de.adorsys.opba.fintech.api")
public class FinTechApiConfig {
}
