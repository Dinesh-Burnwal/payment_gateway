package de.adorsys.opba.fintech.api.resource;

import de.adorsys.opba.fintech.api.resource.generated.FinTechAccountInformationApi;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AccountInformationResource implements FinTechAccountInformationApi {
}
