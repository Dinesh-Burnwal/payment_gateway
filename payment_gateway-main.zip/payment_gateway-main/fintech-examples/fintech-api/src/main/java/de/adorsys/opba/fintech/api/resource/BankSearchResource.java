package de.adorsys.opba.fintech.api.resource;

import de.adorsys.opba.fintech.api.resource.generated.FinTechBankSearchApi;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class BankSearchResource implements FinTechBankSearchApi {
}
