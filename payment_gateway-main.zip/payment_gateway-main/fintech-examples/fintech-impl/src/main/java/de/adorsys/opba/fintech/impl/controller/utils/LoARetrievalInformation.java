package de.adorsys.opba.fintech.impl.controller.utils;

public enum LoARetrievalInformation {
    FROM_TPP_WITH_AVAILABLE_CONSENT,
    FROM_TPP_WITH_NEW_CONSENT
}
