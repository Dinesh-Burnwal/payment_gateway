package de.adorsys.opba.fintech.impl.controller.utils;

public enum OkOrNotOk {
    OK,
    NOT_OK
}
