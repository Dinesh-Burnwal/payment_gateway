package de.adorsys.opba.fintech.impl.exceptions;

public class EmailNotVerified extends IllegalStateException {

    public EmailNotVerified(String msg) {
        super(msg);
    }
}
