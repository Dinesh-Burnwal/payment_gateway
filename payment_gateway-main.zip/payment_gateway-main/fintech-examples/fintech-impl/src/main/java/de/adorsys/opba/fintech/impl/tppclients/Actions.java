package de.adorsys.opba.fintech.impl.tppclients;

public enum Actions {

    LIST_ACCOUNTS
}
