# Fintech Server

Deploys FinTech API

```
> mvn clean install
> mvn spring-boot:run

then http://localhost:8086
```
